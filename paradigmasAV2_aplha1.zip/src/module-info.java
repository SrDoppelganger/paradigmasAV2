/**
 * 
 */
/**
 * 
 */
module paradigmasAV2 {
}